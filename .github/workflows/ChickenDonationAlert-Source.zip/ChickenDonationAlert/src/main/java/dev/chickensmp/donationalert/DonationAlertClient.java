package dev.chickensmp.donationalert;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DonationAlertClient implements ClientModInitializer {
    private static final Pattern PAYMENT_PATTERN = Pattern.compile(
            "(?i)Normalda\\s+(.+?)\\s+oyuncusundan\\s+([0-9][0-9.,]*)\\s*\\$\\s+aldınız!?"
    );

    private static volatile String senderName = "";
    private static volatile String amountText = "";
    private static volatile long visibleUntil = 0L;

    @Override
    public void onInitializeClient() {
        // Server system messages are usually GAME messages. CHAT is also checked
        // in case the server sends the payment notice as a regular chat message.
        ClientReceiveMessageEvents.GAME.register((message, overlay) ->
                handleIncomingMessage(message.getString()));

        ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, timestamp) ->
                handleIncomingMessage(message.getString()));

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath("chicken_donation_alert", "donation_alert"),
                DonationAlertClient::renderAlert
        );
    }

    private static void handleIncomingMessage(String rawMessage) {
        Matcher matcher = PAYMENT_PATTERN.matcher(rawMessage);
        if (!matcher.find()) {
            return;
        }

        String name = matcher.group(1).trim();
        String digits = matcher.group(2).replaceAll("[^0-9]", "");
        if (name.isEmpty() || digits.isEmpty()) {
            return;
        }

        try {
            BigInteger amount = new BigInteger(digits);
            senderName = name;
            amountText = "+" + compactAmount(amount) + "$";
            visibleUntil = System.currentTimeMillis() + 5_000L;
        } catch (NumberFormatException ignored) {
            // Ignore malformed messages rather than interrupting the game.
        }
    }

    private static String compactAmount(BigInteger amount) {
        BigDecimal value = new BigDecimal(amount);
        BigDecimal million = new BigDecimal("1000000");
        BigDecimal billion = new BigDecimal("1000000000");
        BigDecimal thousand = new BigDecimal("1000");

        if (amount.compareTo(BigInteger.valueOf(1_000_000_000L)) >= 0) {
            return trim(value.divide(billion, 2, RoundingMode.DOWN)) + "B";
        }
        if (amount.compareTo(BigInteger.valueOf(1_000_000L)) >= 0) {
            return trim(value.divide(million, 2, RoundingMode.DOWN)) + "M";
        }
        if (amount.compareTo(BigInteger.valueOf(1_000L)) >= 0) {
            return trim(value.divide(thousand, 2, RoundingMode.DOWN)) + "K";
        }
        return amount.toString();
    }

    private static String trim(BigDecimal value) {
        return value.stripTrailingZeros().toPlainString();
    }

    private static void renderAlert(GuiGraphics graphics, net.minecraft.client.DeltaTracker tickCounter) {
        if (System.currentTimeMillis() > visibleUntil || senderName.isEmpty()) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        int screenWidth = graphics.guiWidth();
        int right = screenWidth - 10;
        int panelWidth = Math.max(142, minecraft.font.width(senderName) + minecraft.font.width(amountText) + 42);
        int left = right - panelWidth;
        int top = 12;
        int bottom = top + 38;

        // Subtle dark-green background with a green edge.
        graphics.fill(left, top, right, bottom, 0xD9102418);
        graphics.fill(left, top, left + 3, bottom, 0xFF35D06F);

        graphics.drawString(minecraft.font, "PUL GƏLDİ", left + 10, top + 6, 0xFF8BEEA8, false);
        graphics.drawString(minecraft.font, senderName, left + 10, top + 21, 0xFFFFFFFF, false);

        int amountWidth = minecraft.font.width(amountText);
        graphics.drawString(minecraft.font, amountText, right - amountWidth - 9, top + 13, 0xFF4DFF83, true);
    }
}

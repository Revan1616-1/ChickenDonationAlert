CHICKEN DONATION ALERT
Minecraft Java 1.21.11 | Fabric | Müştəri tərəfli mod

NƏ EDİR?
- Bu mesajı tanıyır:
  Normalda Ali oyuncusundan 1000000$ aldınız!
- Sağ yuxarıda yaşıl bildiriş göstərir.
- Oyunçunun adını və məbləği göstərir.
- 1.000.000 -> 1M, 500.000.000 -> 500M, 1.000.000.000 -> 1B.
- Bildiriş 5 saniyə görünür.
- Serverə plugin quraşdırmaq tələb etmir; yalnız sənin Minecraft client-ində işləyir.

QURULMA / JAR YARATMA
1. Java 21 JDK quraşdır.
2. Layihə qovluğunu IntelliJ IDEA-da Gradle layihəsi kimi aç.
3. Gradle sync tamamlanandan sonra Gradle panelindən Tasks > build > build seç.
   Alternativ olaraq layihə qovluğunda:
   Windows: gradle build
4. Hazır JAR build/libs qovluğunda yaranacaq.
5. Həmin JAR-ı Minecraft 1.21.11 Fabric profilinin mods qovluğuna qoy.
6. Fabric API 0.141.1+1.21.11 də mods qovluğunda olmalıdır.

QEYD
Bu, ilkin mənbə layihəsidir; burada hazır .jar kimi kompilyasiya olunmayıb.
ChickenSMP-də mesajın server tərəfindən client-ə həqiqətən göndərilməsi vacibdir.
Əgər server mesajın mətnini dəyişirsə (rəng kodları və ya başqa sözlər), parser-i həmin
dəqiq mətnə uyğunlaşdırmaq lazım gələ bilər.

Versiyalar: Minecraft 1.21.11, Fabric Loader 0.18.4, Fabric API 0.141.1+1.21.11,
Java 21. Loom 1.14-SNAPSHOT.
